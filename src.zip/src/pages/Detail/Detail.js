import React from 'react';
const Detail = () => {
  return <>상세</>;
};
export default Detail;
