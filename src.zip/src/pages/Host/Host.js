import React from 'react';
const Host = () => {
  return <>호스트</>;
};
export default Host;
