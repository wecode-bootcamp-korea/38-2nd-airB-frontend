import React from 'react';
const LocalNav = () => {
  return <>로컬</>;
};
export default LocalNav;
