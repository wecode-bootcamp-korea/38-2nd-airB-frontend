import React from 'react';
const GlobalNav = () => {
  return <>글로벌</>;
};
export default GlobalNav;
